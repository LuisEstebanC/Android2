package com.example.finalp;

public interface ComunicaMenu {
    public void menu(int queboton );
    public  void menuAside (int quebotonAside);
}
